package com.ars.alpha.other;

public enum Status {
    SUCCESS,
    WARNING,
    ERROR
}
